<?php

return [

    /*
    |-------------------------------------------------------------
    | App Id
    |-------------------------------------------------------------
    |
    | The Id of your Aylien application.
    | https://developer.aylien.com/admin/applications
    |
    */

    'app_id' => 'XXXXXXXX',

    /*
    |-------------------------------------------------------------
    | App Key
    |-------------------------------------------------------------
    |
    | One of the application keys for the above Aylien app
    | https://developer.aylien.com/admin/applications/XXXXXXXXXXXXXX
    |
    */
    'app_key' => 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
];
