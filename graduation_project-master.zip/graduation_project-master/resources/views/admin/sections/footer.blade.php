<div class="pull-right">
    &copy; {{ date('Y') }} {{ config('app.name') }}. {{ __('views.backend.section.footer.copyright') }}
</div>
<div class="clearfix"></div>
